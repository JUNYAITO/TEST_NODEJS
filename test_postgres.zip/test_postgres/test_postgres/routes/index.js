var express = require('express');
var router = express.Router();
var moment = require('moment');
var pg = require('pg');
var sequelize = require('sequelize');

const sampleDB = new sequelize('PostgresSQL', 'postgres', 'P@ssw0rd', {
    host: 'localhost',
    dialect: 'postgres',
    port :5432
});

//DBとのコネクションストリング
const config = {
    host: '172.16.41.93',
    user: 'postgres',     
    password: 'P@ssw0rd',
    database: 'sample',
    port: 5432,
    ssl: false
};

router.get('/', function(req, res, next) {
    //レンダリングする箇所
    res.render('index', { title: 'Express' });
  });


/*
 PATHを同一にして、ボタンのtypeとかで処理の分岐ができたらよい。
*/
router.post('/update', function(req, res, next) {
    var value = req.body.updateValue;
  
    var client = new pg.Client(config);
    client.connect(err => {
        if (err) throw err;
        else {
            updateTable(client,value);
        }
    });
  });
  
  router.post('/select', function(req, res, next) {
      var client = new pg.Client(config);
      client.connect(err => {
          if (err) throw err;
          else {
              selectTable(client);
          }
      });
    });
  
  router.post('/delete', function(req, res, next) {
      var client = new pg.Client(config);
      client.connect(err => {
          if (err) throw err;
          else {
              deleteTable(client);
          }
      });
    });
  
  function updateTable(client,val) {
    const query = `INSERT INTO testtable1 (no) VALUES ($1);`;
    client
        .query(query,[val])
        .then(() => {
            console.log('更新できました');
            client.end(console.log('Closed client connection'));
        })
        .catch(err => console.log(err));
  }
  
  function deleteTable(client) {
      const query = `DELETE FROM testtable1`;
      client
          .query(query)
          .then(() => {
              console.log('削除できました');
              client.end(console.log('Closed client connection'));
          })
          .catch(err => console.log(err));
    }
  
  function selectTable(client) {
      console.log('データ取得前');
      const query = `SELECT no from testtable1;`;
      client
          .query(query, function(err,result){
              var i = 0;
              if (result != null && result.rows.length != 0){
                  result.rows.forEach(element => {
                      console.log(result.rows[i].no);
                      i++;
                  });
              }else{
                  console.log('データは取得できませんでした');
              };
              client.end(console.log('Closed client connection'));
          });
  }


// const sampletable2 = sampleDB.define('sampletable2', {
//     id: {
//         type: sequelize.BIGINT, allowNull:false, primaryKey: false 
//     },
//     comment: {
//         type: sequelize.TEXT, allowNull:false, primaryKey: false 
//     },
//     createdat:{
//         type: sequelize.DATE, field: 'created_at', primaryKey: false 
//     }
// }, {
//     freezeTableName: true
// });

// const sampletable3 = sampleDB.define('sampletable3', {
//     // フィールド名
//     firstName: {
//         // フィールドの型
//         type: sequelize.STRING,
//         // DB上のフィールド名
//         field: 'first_name'
//     },
//     lastName: {
//         type: sequelize.STRING
//     }
// }, {
//     // モデル名をそのままテーブル名として使う
//     freezeTableName: true
// });

// sampletable2.sync().then(() => {
//     console.log('created table')
// });

// sampletable3.create({
//     firstName: 'Rikko',
//     lastName: 'BC'
// }).then(result => {
//     console.log('created:', result.firstName);
// });

// router.post('/', function(req, res, next) {
//   //検証やテストのロジック  
//   var title = req.body.title;
//   var createdAt = moment().format('YYYY-MM-DD HH:mm:ss'); 
//   console.log(title);
//   console.log(createdAt);
// });



module.exports = router;
